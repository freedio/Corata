/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.trouble

import com.coradec.coradeck.core.trouble.BasicException

open class CoraTradeException : BasicException() {

}
