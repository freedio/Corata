/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.trouble

class NoSuchAccountFieldException(val key: String) : CoraTradeException() {

}
