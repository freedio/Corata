/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.model

import com.coradec.coratrade.interactive.model.impl.BasicTradeOrder
import com.ib.client.Contract
import com.ib.client.Order
import com.ib.client.OrderState

interface TradeOrder {
    companion object {
        fun of(contract: Contract, order: Order, orderState: OrderState) = BasicTradeOrder(contract, order, orderState)
    }
}
