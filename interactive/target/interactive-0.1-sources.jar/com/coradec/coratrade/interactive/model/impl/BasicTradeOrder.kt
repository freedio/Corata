/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.model.impl

import com.coradec.coratrade.interactive.model.TradeOrder
import com.ib.client.Contract
import com.ib.client.Order
import com.ib.client.OrderState

class BasicTradeOrder(
        val contract: Contract,
        val order: Order,
        val orderState: OrderState
): TradeOrder
