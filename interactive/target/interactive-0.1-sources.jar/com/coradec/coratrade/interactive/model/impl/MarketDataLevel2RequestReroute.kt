/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.model.impl

import com.coradec.coratrade.interactive.model.MarketDataRequestReroute

class MarketDataLevel2RequestReroute(val conId: Int, val exchange: String) : MarketDataRequestReroute
