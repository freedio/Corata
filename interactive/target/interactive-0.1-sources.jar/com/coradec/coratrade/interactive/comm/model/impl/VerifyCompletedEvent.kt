/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.comm.model.impl

import com.coradec.coradeck.com.model.impl.BasicEvent
import com.coradec.coradeck.core.ctrl.Origin
import java.time.LocalDateTime.now

class VerifyCompletedEvent(origin: Origin, val successful: Boolean, val errorText: String?): BasicEvent(origin, now())
