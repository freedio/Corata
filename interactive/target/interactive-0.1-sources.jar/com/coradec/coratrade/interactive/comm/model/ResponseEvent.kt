/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.comm.model

import com.coradec.coradeck.com.model.Event

interface ResponseEvent : Event
