/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.comm.model.impl

import com.coradec.coratrade.interactive.ctrl.EventDispatcher
import com.ib.client.Bar
import java.time.LocalDateTime.now

class HistoricalDataUpdateEvent(origin: EventDispatcher, requestId: Int, val bar: Bar): BasicResponseEvent(origin, requestId, now())
