/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.comm.model.impl

import com.coradec.coradeck.core.ctrl.Origin
import java.time.LocalDateTime.now

class SecurityDefinitionOptionParameterEndEvent(origion: Origin, requestId: Int): BasicResponseEvent(origion, requestId, now())
