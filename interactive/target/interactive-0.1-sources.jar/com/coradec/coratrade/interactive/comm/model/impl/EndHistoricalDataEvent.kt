/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.comm.model.impl

import com.coradec.coratrade.interactive.ctrl.EventDispatcher
import java.time.LocalDateTime.now

class EndHistoricalDataEvent(origin: EventDispatcher, requestId: Int, val start: String, val end: String):
        BasicResponseEvent(origin, requestId, now())
