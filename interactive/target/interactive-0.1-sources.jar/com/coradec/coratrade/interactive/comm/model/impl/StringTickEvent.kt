/*
 * Copyright ⓒ 2019. by Coradec LLC. All rights reserved.
 */

package com.coradec.coratrade.interactive.comm.model.impl

import com.coradec.coradeck.com.model.impl.BasicEvent
import com.coradec.coratrade.interactive.ctrl.EventDispatcher
import com.coradec.coratrade.interactive.model.StringTick
import java.time.LocalDateTime.now

class StringTickEvent(origin: EventDispatcher, val tick: StringTick): BasicEvent(origin, now())
