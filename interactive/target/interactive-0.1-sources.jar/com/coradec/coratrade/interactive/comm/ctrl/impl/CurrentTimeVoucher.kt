/*
 * Copyright © 2019 by Coradec LLC.  All rights reserved.
 */

package com.coradec.coratrade.interactive.comm.ctrl.impl

import com.coradec.coradeck.com.model.Information
import com.coradec.coradeck.core.ctrl.Origin
import com.coradec.coradeck.core.model.Duration
import com.coradec.coradeck.type.model.GenericType
import com.coradec.coratrade.interactive.comm.model.impl.CurrentTimeEvent
import com.coradec.coratrade.interactive.ctrl.CommandDispatcher
import java.time.Instant
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZonedDateTime
import java.time.temporal.ChronoUnit
import java.util.concurrent.TimeUnit.NANOSECONDS

class CurrentTimeVoucher(origin: Origin) :
        CommandDispatcher.IBrokerVoucher<LocalDateTime>(GenericType.of(LocalDateTime::class.java), origin) {
    private lateinit var myLocalTime: ZonedDateTime
    val Δt get() = Duration.of(ChronoUnit.NANOS.between(value, myLocalTime), NANOSECONDS)
    val localTime: ZonedDateTime by lazy {
        standby()
        myLocalTime
    }
    override val interests: Set<Class<out Information>> = setOf(CurrentTimeEvent::class.java)
    override val action = CommandDispatcher::requestCurrentTime

    override fun notify(info: Information): Boolean {
        if (info is CurrentTimeEvent) {
            myLocalTime = Instant.ofEpochMilli(System.currentTimeMillis()).atZone(ZoneId.systemDefault())
            setValue(info.localTime)
        }
        return true
    }

}
