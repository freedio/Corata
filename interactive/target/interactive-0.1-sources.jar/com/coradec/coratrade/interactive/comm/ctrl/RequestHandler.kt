/*
 * Copyright © 2019 by Coradec LLC.  All rights reserved.
 */

package com.coradec.coratrade.interactive.comm.ctrl

import com.coradec.coradeck.com.model.Observer

interface RequestHandler: Observer {
}
