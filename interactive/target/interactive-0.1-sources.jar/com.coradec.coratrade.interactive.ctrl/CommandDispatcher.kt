/*
 * Copyright © 2019 by Coradec LLC.  All rights reserved.
 */

package com.coradec.coratrade.interactive.ctrl

import com.coradec.coradeck.com.ctrl.TypedObserver
import com.coradec.coradeck.com.model.Observer
import com.coradec.coradeck.com.model.impl.BasicRequest
import com.coradec.coradeck.com.model.impl.BasicVoucher
import com.coradec.coradeck.core.ctrl.Origin
import com.coradec.coradeck.ctrl.ctrl.impl.BasicAgent
import com.coradec.coradeck.ctrl.module.CoraControl
import com.coradec.coradeck.text.model.LocalizedText
import com.coradec.coradeck.type.model.GenericType
import com.coradec.coratrade.interactive.model.AccountField
import com.ib.client.EClientSocket
import com.ib.client.EJavaSignal
import com.ib.client.EReader
import java.time.LocalDateTime
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.reflect.KFunction1

object CommandDispatcher : BasicAgent() {
    private val signal = EJavaSignal()
    private val client by lazy { EClientSocket(EventDispatcher, signal) }
    private val reader by lazy { EReader(client, signal) }
    private val processor = Thread(::process, "SignalProcessor")
    private var connected: Boolean = false

    private val TEXT_STARTING_COMMAND_DISPATCHER = LocalizedText.define("StartingCommandDispatcher")
    private val TEXT_SHUTTING_DOWN_COMMAND_DISPATCHER = LocalizedText.define("ShuttingDownCommandDispatcher")
    private val TEXT_SIGNAL_PROCESSOR_STARTED = LocalizedText.define("SignalProcessorStarted")
    private val TEXT_SIGNAL_PROCESSOR_ENDED = LocalizedText.define("SignalProcessorTerminated")

    init {
        info(TEXT_STARTING_COMMAND_DISPATCHER)
        client.eConnect("localhost", 10000, 0)
        connected = true
        reader.start()
        processor.isDaemon = true
        processor.start()
        addRoute(IBrokerRequest::class.java, ::handleRequest)
        addRoute(IBrokerVoucher::class.java, ::handleVoucher)
        requestAccountSummaries()
//        requestCurrentTime()
        TimeUnit.SECONDS.sleep(1)
    }

    private fun handleVoucher(voucher: IBrokerVoucher<*>) {
        voucher.action.invoke(voucher)
    }

    private fun handleRequest(request: IBrokerRequest) {
        TODO("Don't know how to handle this!")
    }

    private fun process() {
        info(TEXT_SIGNAL_PROCESSOR_STARTED)
        while (client.isConnected) {
            signal.waitForSignal()
            reader.processMsgs()
        }
        info(TEXT_SIGNAL_PROCESSOR_ENDED)
    }

    fun shutdown() {
        info(TEXT_SHUTTING_DOWN_COMMAND_DISPATCHER, client.twsConnectionTime)
        connected = false
        client.eDisconnect()
        TimeUnit.SECONDS.sleep(1)
    }

    fun requestCurrentTime(observer: Observer) {
        CoraControl.messageQueue.subscribe(observer)
        client.reqCurrentTime()
    }

    fun requestAccountSummaries(
            account: String = "All",
            fields: EnumSet<AccountField> = EnumSet.allOf(AccountField::class.java)) {
//        val requestId = createRequest()
//        client.reqAccountSummary(requestId, account, fields.joinToString(","))
}

    class CommandPalette() {
    }

    abstract class IBrokerRequest(origin: Origin, urgent: Boolean, createdAt: LocalDateTime, id: UUID) :
            BasicRequest(origin, CommandDispatcher, urgent, createdAt, id) {
    }

    abstract class IBrokerVoucher<V>(
            type: GenericType<V>,
            origin: Origin,
            urgent: Boolean = false,
            createdAt: LocalDateTime = LocalDateTime.now(),
            id: UUID = UUID.randomUUID()
    ) :
            BasicVoucher<V>(origin, CommandDispatcher, type, urgent, createdAt, id), TypedObserver {
        val menucard = CommandPalette()
        abstract val action: KFunction1<@ParameterName(name = "observer") Observer, Unit>
    }

}
